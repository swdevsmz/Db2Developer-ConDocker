------------------------------
-- IMPORT DATA

IMPORT FROM member.csv OF DEL REPLACE INTO MEMBER ;
IMPORT FROM division.csv OF DEL REPLACE INTO DIVISION ;
